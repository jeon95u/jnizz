package domain.company.app_name;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

{{argv_set_and_func_call}}

    }

    static {
        System.loadLibrary("{{so_file_name}}");
    }

{{jni_funcion_list}}
}
